"""
AATAS — An AI-Assisted Technological Arrangement System
Telegram Bot — Main Entry Point

Features:
  - Multi-user with self-service Gmail OAuth onboarding
  - Conversational AI (Claude-powered) — natural language for everything
  - Persistent automation rules ("archive anything about Google Classroom")
  - Rule engine runs automatically on /check and scheduled scans
  - Full email management: archive, label, reply, prioritise, summarise
"""

import asyncio
import logging
import os
from typing import Optional

from telegram import (
    InlineKeyboardButton, InlineKeyboardMarkup,
    Update, BotCommand,
)
from telegram.ext import (
    Application, CallbackQueryHandler, CommandHandler,
    ContextTypes, MessageHandler, filters,
)

from api.brain     import AATASBrain
from api.gmail_auth import get_auth_url, get_gmail_service
from api.gmail_ops  import (
    archive_email, apply_label, apply_rules, fetch_emails,
    mark_read, send_reply, trash_email,
)
from db.database   import (
    ActionLog, AutomationRule, SessionLocal,
    add_rule, get_or_create_user, get_rules, log_action, upsert_memory,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

TELEGRAM_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
brain          = AATASBrain()

# In-memory email cache: {telegram_id: [email_dict]}
_cache: dict[int, list[dict]] = {}

PRIORITY_ICON = {"urgent": "🔴", "important": "🟡", "normal": "🟢", "low": "⚪"}


# ── Helpers ────────────────────────────────────────

def _db():
    return SessionLocal()

def _get_user(update: Update):
    db   = _db()
    user = get_or_create_user(
        db,
        update.effective_user.id,
        update.effective_user.full_name,
    )
    return db, user

def _cached(tg_id: int, n: int) -> Optional[dict]:
    emails = _cache.get(tg_id, [])
    return emails[n - 1] if 1 <= n <= len(emails) else None

async def _typing(update: Update):
    await update.effective_chat.send_action("typing")


# ── /start ─────────────────────────────────────────

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db, user = _get_user(update)
    db.close()
    name = update.effective_user.first_name or "there"

    if user.setup_complete:
        await update.message.reply_text(
            f"👋 Welcome back, *{name}*!\n\n"
            "I'm AATAS — your AI-Assisted Technological Arrangement System.\n"
            "Just talk to me naturally — I understand what you need.\n\n"
            "Try: _\"show my inbox\"_ or _\"archive anything about promotions\"_",
            parse_mode="Markdown",
        )
    else:
        await cmd_setup(update, ctx)


# ── /setup — multi-user onboarding ─────────────────

async def cmd_setup(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db, user = _get_user(update)
    tg_id    = update.effective_user.id
    db.close()

    auth_url = get_auth_url(state=str(tg_id))

    kbd = InlineKeyboardMarkup([[
        InlineKeyboardButton("🔗 Connect Gmail", url=auth_url)
    ]])

    await update.message.reply_text(
        "🤖 *Welcome to AATAS*\n"
        "_An AI-Assisted Technological Arrangement System_\n\n"
        "To get started, I need access to your Gmail so I can:\n"
        "• 📬 Read & manage your emails\n"
        "• 🤖 Apply your automation rules\n"
        "• 📊 Prioritise and summarise\n\n"
        "Tap the button below to authorise Gmail access.\n"
        "Your data stays private — only you control AATAS.",
        parse_mode="Markdown",
        reply_markup=kbd,
    )


# ── /help ──────────────────────────────────────────

async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 *AATAS — How to use me*\n\n"
        "*Just talk to me naturally!* For example:\n"
        '• _"Show my inbox"_\n'
        '• _"Archive anything about Google Classroom"_\n'
        '• _"Analyse email 3"_\n'
        '• _"Draft a reply to email 2"_\n'
        '• _"What automation rules do I have?"_\n'
        '• _"Delete the rule about newsletters"_\n'
        '• _"Check for new emails and apply my rules"_\n\n'
        "*Commands:*\n"
        "/setup — Connect or reconnect Gmail\n"
        "/inbox — Quick inbox view\n"
        "/check — Apply your rules to new emails\n"
        "/rules — List your automation rules\n"
        "/history — Recent actions AATAS took\n"
        "/help — This message",
        parse_mode="Markdown",
    )


# ── /inbox ─────────────────────────────────────────

async def cmd_inbox(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db, user = _get_user(update)
    if not user.setup_complete:
        await update.message.reply_text("Please run /setup first to connect Gmail.")
        db.close(); return

    msg = await update.message.reply_text("⏳ Fetching inbox...")
    try:
        svc    = get_gmail_service(user)
        emails = fetch_emails(svc, max_results=10)
        _cache[user.telegram_id] = emails

        if not emails:
            await msg.edit_text("📭 No unread emails!")
            db.close(); return

        lines = ["📬 *Your unread inbox:*\n"]
        for e in emails:
            lines.append(f"`{e['idx']}.` *{e['subject'][:45]}*\n   👤 {e['sender'][:35]}\n")
        lines.append("\n_Say \"analyse 3\" or \"archive 2\" to take action._")
        await msg.edit_text("\n".join(lines), parse_mode="Markdown")

    except Exception as ex:
        await msg.edit_text(f"❌ {ex}")
    finally:
        db.close()


# ── /check — run rules on new emails ───────────────

async def cmd_check(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db, user = _get_user(update)
    if not user.setup_complete:
        await update.message.reply_text("Please run /setup first."); db.close(); return

    rules = get_rules(db, user.id)
    if not rules:
        await update.message.reply_text(
            "You have no automation rules yet.\n"
            'Try: _"archive anything about Google Classroom"_',
            parse_mode="Markdown"
        )
        db.close(); return

    msg = await update.message.reply_text(f"⏳ Checking inbox against {len(rules)} rules...")
    try:
        svc     = get_gmail_service(user)
        emails  = fetch_emails(svc, max_results=50, query="is:unread")
        applied = apply_rules(svc, db, user.id, emails, rules)

        if not applied:
            await msg.edit_text("✅ Checked inbox — no rules triggered.")
        else:
            lines = [f"✅ *AATAS applied {len(applied)} actions:*\n"]
            for a in applied[:10]:
                lines.append(f"• {a['action'].title()}: _{a['email']['subject'][:45]}_")
            if len(applied) > 10:
                lines.append(f"...and {len(applied)-10} more.")
            await msg.edit_text("\n".join(lines), parse_mode="Markdown")

    except Exception as ex:
        await msg.edit_text(f"❌ {ex}")
    finally:
        db.close()


# ── /rules ─────────────────────────────────────────

async def cmd_rules(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db, user = _get_user(update)
    rules    = get_rules(db, user.id)
    db.close()

    if not rules:
        await update.message.reply_text(
            "You have no rules yet.\n\n"
            "Tell me what to automate, e.g.:\n"
            '_"Archive anything about Google Classroom"_\n'
            '_"Label emails from boss@work.com as important"_',
            parse_mode="Markdown"
        )
        return

    lines = ["⚙️ *Your automation rules:*\n"]
    for r in rules:
        lines.append(
            f"`[{r.id}]` {r.action.upper()} — _{r.rule_text}_\n"
            f"   Triggered {r.trigger_count}× since {r.created_at.strftime('%d %b')}\n"
        )
    lines.append("\n_Say \"delete rule 3\" to remove a rule._")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ── /history ────────────────────────────────────────

async def cmd_history(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db, user = _get_user(update)
    logs     = (
        db.query(ActionLog)
        .filter_by(user_id=user.id)
        .order_by(ActionLog.created_at.desc())
        .limit(15)
        .all()
    )
    db.close()

    if not logs:
        await update.message.reply_text("No actions taken yet."); return

    lines = ["📋 *Recent AATAS actions:*\n"]
    for l in logs:
        ts = l.created_at.strftime("%d %b %H:%M")
        lines.append(f"`{ts}` {l.action.upper()} — _{l.email_subject[:45]}_")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ── Conversational message handler ─────────────────

async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """The heart of AATAS — natural language understanding via Claude."""
    db, user = _get_user(update)
    tg_id    = user.telegram_id
    text     = update.message.text.strip()

    if not user.setup_complete:
        await update.message.reply_text(
            "I need to connect to your Gmail first. Run /setup to get started!"
        )
        db.close(); return

    await _typing(update)

    try:
        # Get Gmail service (for context hints)
        svc = None
        try:
            svc = get_gmail_service(user)
        except Exception:
            pass

        # Inject current email cache as context hint
        cached = _cache.get(tg_id, [])
        ctx_hint = ""
        if cached:
            ctx_hint = "Current email cache (from last /inbox):\n" + "\n".join(
                f"{e['idx']}. Subject: {e['subject']} | From: {e['sender']}" for e in cached[:10]
            )

        # Ask the AI brain
        reply_text, intent = brain.chat(db, user, text, context_hint=ctx_hint)

        # Execute intent
        if intent:
            await _execute_intent(update, ctx, db, user, svc, intent, reply_text)
        else:
            await update.message.reply_text(reply_text or "I didn't quite catch that.", parse_mode="Markdown")

    except Exception as ex:
        log.exception("handle_message error")
        await update.message.reply_text(f"❌ Something went wrong: {ex}")
    finally:
        db.close()


async def _execute_intent(update, ctx, db, user, svc, intent: dict, ai_reply: str):
    """Dispatch actions based on the AI's parsed intent."""
    action   = intent.get("intent", "none")
    idx      = intent.get("email_idx")
    tg_id    = user.telegram_id

    # Always send the AI's conversational reply first
    if ai_reply:
        await update.message.reply_text(ai_reply, parse_mode="Markdown")

    if action == "fetch_inbox":
        if svc:
            emails = fetch_emails(svc, max_results=10)
            _cache[tg_id] = emails
            if emails:
                lines = ["📬 *Inbox:*\n"]
                for e in emails:
                    lines.append(f"`{e['idx']}.` *{e['subject'][:45]}*\n   👤 {e['sender'][:35]}\n")
                await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    elif action == "fetch_priority":
        if svc:
            emails = fetch_emails(svc, max_results=15)
            _cache[tg_id] = emails
            scored = []
            for e in emails:
                priority, conf = brain.classify_priority(e["subject"], e["body"])
                scored.append((e, priority, conf))
            order = {"urgent": 0, "important": 1, "normal": 2, "low": 3}
            scored.sort(key=lambda x: order.get(x[1], 9))
            lines = ["📊 *Inbox by priority:*\n"]
            for e, p, c in scored:
                icon = PRIORITY_ICON.get(p, "•")
                lines.append(f"`{e['idx']}.` {icon} `{p}` — {e['subject'][:40]}")
            await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    elif action == "analyse" and idx:
        e = _cached(tg_id, idx)
        if not e:
            await update.message.reply_text(f"Email #{idx} not in cache. Say 'show my inbox' first.")
            return
        msg = await update.message.reply_text("🧠 Analysing...")
        priority, conf = brain.classify_priority(e["subject"], e["body"])
        summary = brain.summarise_email(e["subject"], e["body"])
        actions = brain.extract_actions(e["subject"], e["body"])
        draft   = brain.draft_reply(e["subject"], e["body"])

        icon = PRIORITY_ICON.get(priority, "•")
        text = (
            f"📧 *{e['subject'][:50]}*\n"
            f"👤 {e['sender']}\n\n"
            f"Priority: {icon} `{priority}` ({conf:.0%})\n\n"
            f"📝 *Summary:*\n{summary}\n\n"
            f"✅ *Actions:*\n" + ("\n".join(f"• {a}" for a in actions) or "None") +
            f"\n\n💬 *Draft reply:*\n_{draft}_"
        )
        kbd = InlineKeyboardMarkup([[
            InlineKeyboardButton("📤 Archive", callback_data=f"archive:{e['id']}"),
            InlineKeyboardButton("✅ Mark read", callback_data=f"markread:{e['id']}"),
        ]])
        await msg.edit_text(text, parse_mode="Markdown", reply_markup=kbd)

    elif action == "archive" and idx:
        e = _cached(tg_id, idx)
        if not e or not svc: return
        archive_email(svc, e["id"])
        log_action(db, user.id, "archive", e["id"], e["subject"], "manual")
        await update.message.reply_text(f"📦 Archived: _{e['subject']}_", parse_mode="Markdown")

    elif action == "trash" and idx:
        e = _cached(tg_id, idx)
        if not e or not svc: return
        trash_email(svc, e["id"])
        log_action(db, user.id, "trash", e["id"], e["subject"], "manual")
        await update.message.reply_text(f"🗑 Trashed: _{e['subject']}_", parse_mode="Markdown")

    elif action == "reply" and idx:
        e    = _cached(tg_id, idx)
        tone = intent.get("action_params", {}).get("tone", "professional")
        if not e: return
        draft = brain.draft_reply(e["subject"], e["body"], tone)
        kbd = InlineKeyboardMarkup([[
            InlineKeyboardButton("📤 Send this reply", callback_data=f"sendreply:{e['id']}:{idx}"),
            InlineKeyboardButton("❌ Cancel", callback_data="cancel"),
        ]])
        await update.message.reply_text(
            f"💬 *Draft reply ({tone}):*\n\n_{draft}_",
            parse_mode="Markdown", reply_markup=kbd
        )

    elif action == "create_rule":
        rule_data = intent.get("rule", {})
        if rule_data:
            target = {
                "keywords": rule_data.get("keywords", []) or rule_data.get("target", {}).get("keywords", []),
                "from":     rule_data.get("from", "") or rule_data.get("target", {}).get("from", ""),
                "label":    rule_data.get("label", "") or rule_data.get("target", {}).get("label", ""),
            }
            rule = add_rule(
                db, user.id,
                rule_text = rule_data.get("rule_text", "User rule"),
                action    = rule_data.get("action", "archive"),
                target    = target,
            )
            await update.message.reply_text(
                f"⚙️ *Rule created!*\n\n"
                f"ID: `{rule.id}`\n"
                f"Action: `{rule.action}`\n"
                f"Keywords: `{', '.join(target['keywords']) or 'any'}`\n\n"
                f"AATAS will apply this every time you run /check or I scan your inbox.\n"
                f"Want me to run it on your inbox now? Say _\"yes, check now\"_",
                parse_mode="Markdown"
            )

    elif action == "delete_rule":
        rule_id = intent.get("action_params", {}).get("rule_id")
        if rule_id:
            rule = db.query(AutomationRule).filter_by(id=rule_id, user_id=user.id).first()
            if rule:
                rule.enabled = False
                db.commit()
                await update.message.reply_text(f"🗑 Rule `{rule_id}` deleted.", parse_mode="Markdown")

    elif action == "list_rules":
        rules = get_rules(db, user.id)
        if not rules:
            await update.message.reply_text("No rules set. Tell me what to automate!")
        else:
            lines = ["⚙️ *Active rules:*\n"]
            for r in rules:
                lines.append(f"`[{r.id}]` {r.action.upper()} — _{r.rule_text}_ ({r.trigger_count}×)")
            await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    elif action == "list_history":
        logs = (
            db.query(ActionLog).filter_by(user_id=user.id)
            .order_by(ActionLog.created_at.desc()).limit(10).all()
        )
        if not logs:
            await update.message.reply_text("No actions yet.")
        else:
            lines = ["📋 *Recent actions:*\n"]
            for l in logs:
                lines.append(f"• {l.action.upper()}: _{l.email_subject[:40]}_")
            await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ── Inline button callbacks ─────────────────────────

async def button_cb(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q    = update.callback_query
    await q.answer()
    data = q.data
    db, user = _get_user(update)

    try:
        svc = get_gmail_service(user)

        if data.startswith("archive:"):
            msg_id = data.split(":")[1]
            archive_email(svc, msg_id)
            log_action(db, user.id, "archive", msg_id, "email", "inline button")
            await q.edit_message_text("📦 Archived!", parse_mode="Markdown")

        elif data.startswith("markread:"):
            msg_id = data.split(":")[1]
            mark_read(svc, msg_id)
            await q.edit_message_text("✅ Marked as read.", parse_mode="Markdown")

        elif data.startswith("sendreply:"):
            _, msg_id, idx = data.split(":")
            e = _cached(user.telegram_id, int(idx))
            if e:
                draft = brain.draft_reply(e["subject"], e["body"])
                send_reply(svc, e, draft)
                log_action(db, user.id, "reply", msg_id, e["subject"])
                await q.edit_message_text("📤 Reply sent!", parse_mode="Markdown")

        elif data == "cancel":
            await q.edit_message_text("Cancelled.")

    except Exception as ex:
        await q.edit_message_text(f"❌ {ex}")
    finally:
        db.close()


# ── App wiring ──────────────────────────────────────

def build_app() -> Application:
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    app.add_handler(CommandHandler("start",   cmd_start))
    app.add_handler(CommandHandler("setup",   cmd_setup))
    app.add_handler(CommandHandler("help",    cmd_help))
    app.add_handler(CommandHandler("inbox",   cmd_inbox))
    app.add_handler(CommandHandler("check",   cmd_check))
    app.add_handler(CommandHandler("rules",   cmd_rules))
    app.add_handler(CommandHandler("history", cmd_history))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(CallbackQueryHandler(button_cb))

    return app


async def set_commands(app: Application):
    await app.bot.set_my_commands([
        BotCommand("start",   "Start AATAS"),
        BotCommand("setup",   "Connect Gmail"),
        BotCommand("inbox",   "View inbox"),
        BotCommand("check",   "Apply automation rules"),
        BotCommand("rules",   "Manage rules"),
        BotCommand("history", "View action history"),
        BotCommand("help",    "Help"),
    ])


if __name__ == "__main__":
    import asyncio
    log.info("Starting AATAS bot...")
    application = build_app()

    async def post_init(app):
        await set_commands(app)

    application.post_init = post_init
    application.run_polling(drop_pending_updates=True)
