"""
AATAS — AI Conversation Brain
Uses Claude (via Anthropic API) as the conversational intelligence layer.
Understands user intent, extracts automation rules, and responds naturally.
"""

import json
import os
import re
from typing import Optional

import anthropic

from db.database import Session, User, get_conv_history, get_memories, get_rules, save_conv_turn

ANTHROPIC_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

SYSTEM_PROMPT = """You are AATAS — An AI-Assisted Technological Arrangement System.
You help users manage their Gmail inbox intelligently via Telegram.

Your capabilities:
- Show and analyse emails (priority, category, summary, action items)
- Execute actions: archive, label, mark read/unread, trash, reply
- Create persistent automation rules that run automatically on new emails
- Remember user preferences and facts about them

When the user asks you to do something with emails, respond conversationally and also
include a structured JSON block at the END of your response (after all natural text) 
in this format when an action or rule is needed:

```json
{
  "intent": "one of: fetch_inbox | analyse | archive | label | trash | reply | create_rule | delete_rule | list_rules | list_history | fetch_priority | none",
  "email_idx": null,
  "rule": null,
  "action_params": {}
}
```

For create_rule intent, include:
```json
{
  "intent": "create_rule",
  "rule": {
    "rule_text": "original user instruction",
    "action": "archive|label|trash|mark_read",
    "target": {
      "keywords": ["list", "of", "keywords"],
      "from": "optional sender filter",
      "label": "optional label name for label action"
    }
  }
}
```

Examples:
User: "archive anything about Google Classroom"
→ Respond warmly, then JSON with intent=create_rule, action=archive, keywords=["google classroom", "classroom"]

User: "show my inbox"
→ Respond, then JSON with intent=fetch_inbox

User: "analyse email 3"
→ JSON with intent=analyse, email_idx=3

User: "what rules do I have?"
→ JSON with intent=list_rules

Always be warm, concise, and helpful. Use the user's name when you know it.
Never expose the JSON block in a weird way — just include it naturally at the end.
"""


def _extract_json(text: str) -> Optional[dict]:
    """Pull the last JSON block from the AI response."""
    matches = re.findall(r"```json\s*(\{.*?\})\s*```", text, re.DOTALL)
    if not matches:
        return None
    try:
        return json.loads(matches[-1])
    except json.JSONDecodeError:
        return None

def _strip_json(text: str) -> str:
    """Remove JSON block from response before sending to user."""
    return re.sub(r"```json\s*\{.*?\}\s*```", "", text, flags=re.DOTALL).strip()


class AATASBrain:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=ANTHROPIC_KEY)

    def chat(
        self,
        db:         Session,
        user:       User,
        user_message: str,
        context_hint: str = "",     # injected email context, rule list, etc.
    ) -> tuple[str, Optional[dict]]:
        """
        Send a message to AATAS AI.
        Returns (text_response, intent_dict)
        """

        # Build context block
        memories  = get_memories(db, user.id)
        rules     = get_rules(db, user.id)
        history   = get_conv_history(db, user.id, last_n=12)

        mem_text  = "\n".join(f"- {k}: {v}" for k, v in memories.items()) or "None"
        rule_text = "\n".join(f"- [{r.id}] {r.rule_text} (action: {r.action}, triggers: {r.trigger_count})"
                              for r in rules) or "None"

        system = SYSTEM_PROMPT + f"""

Current user context:
- Name: {user.telegram_name or 'Unknown'}
- Gmail: {user.gmail_email or 'Not connected'}
- Memories about this user:
{mem_text}

Active automation rules:
{rule_text}

{f'Additional context: {context_hint}' if context_hint else ''}
"""

        # Build message list
        messages = list(history)   # past turns
        messages.append({"role": "user", "content": user_message})

        response = self.client.messages.create(
            model      = "claude-sonnet-4-20250514",
            max_tokens = 1024,
            system     = system,
            messages   = messages,
        )

        full_text = response.content[0].text
        intent    = _extract_json(full_text)
        clean_txt = _strip_json(full_text)

        # Persist conversation
        save_conv_turn(db, user.id, "user",      user_message)
        save_conv_turn(db, user.id, "assistant", clean_txt)

        return clean_txt, intent

    def extract_rule(self, user_instruction: str) -> dict:
        """
        Standalone call to extract a rule from plain text.
        Used when the main chat loop needs a second pass.
        """
        prompt = f"""Extract an email automation rule from this instruction:
"{user_instruction}"

Respond ONLY with JSON, no other text:
{{
  "action": "archive|label|trash|mark_read",
  "keywords": ["keyword1", "keyword2"],
  "from": "sender filter or empty string",
  "label": "label name if action=label else empty string"
}}"""
        resp = self.client.messages.create(
            model      = "claude-sonnet-4-20250514",
            max_tokens = 256,
            messages   = [{"role": "user", "content": prompt}],
        )
        try:
            text = resp.content[0].text.strip()
            text = re.sub(r"```json|```", "", text).strip()
            return json.loads(text)
        except Exception:
            return {"action": "archive", "keywords": [], "from": "", "label": ""}

    def summarise_email(self, subject: str, body: str) -> str:
        resp = self.client.messages.create(
            model      = "claude-sonnet-4-20250514",
            max_tokens = 200,
            messages   = [{"role": "user", "content":
                f"Summarise this email in 2-3 sentences:\nSubject: {subject}\n\n{body}"}],
        )
        return resp.content[0].text.strip()

    def extract_actions(self, subject: str, body: str) -> list[str]:
        resp = self.client.messages.create(
            model      = "claude-sonnet-4-20250514",
            max_tokens = 300,
            messages   = [{"role": "user", "content":
                f"List action items from this email as a JSON array of strings. "
                f"Respond ONLY with a JSON array:\n"
                f"Subject: {subject}\n\n{body}"}],
        )
        try:
            return json.loads(resp.content[0].text.strip())
        except Exception:
            return [l.lstrip("•- ") for l in resp.content[0].text.splitlines() if l.strip()]

    def draft_reply(self, subject: str, body: str, tone: str = "professional") -> str:
        resp = self.client.messages.create(
            model      = "claude-sonnet-4-20250514",
            max_tokens = 400,
            messages   = [{"role": "user", "content":
                f"Write a {tone} email reply to this email. Just the reply body, no subject line:\n"
                f"Subject: {subject}\n\n{body}"}],
        )
        return resp.content[0].text.strip()

    def classify_priority(self, subject: str, body: str) -> tuple[str, float]:
        resp = self.client.messages.create(
            model      = "claude-sonnet-4-20250514",
            max_tokens = 50,
            messages   = [{"role": "user", "content":
                f'Classify this email priority as one of: urgent, important, normal, low. '
                f'Respond ONLY with JSON: {{"priority": "...", "confidence": 0.0}}\n'
                f'Subject: {subject}\n\n{body[:500]}'}],
        )
        try:
            d = json.loads(resp.content[0].text.strip())
            return d["priority"], d.get("confidence", 0.9)
        except Exception:
            return "normal", 0.5
